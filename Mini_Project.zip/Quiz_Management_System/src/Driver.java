package MyProgram;

import MyProgram.Game;

public class Driver {

	 public static void main(String[] args) {
		 
	  Game g = new Game();
	  g.start();
	  
	   

	  
	 
	  
	 }

	}