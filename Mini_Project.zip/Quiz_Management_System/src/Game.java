
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class Game {
 private ArrayList<Question> questionSet;
 public Game() {
	System.out.println("************************");
	//System.out.println();
	System.out.println("* WELCOME TO JAVA QUIZ *");
	//System.out.println();
	System.out.println("************************");
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your Name: ");
	String name=sc.nextLine();
	System.out.println("Enter your Roll No: ");
	int roll_no=sc.nextInt();
	
	questionSet = new ArrayList<Question>();
	//1
	String q = "Which of the following is not a Java features?";
	String[] a = {"Dynamic", "Architecture Neutral", "Use of pointers", "Object-oriented"};
	questionSet.add(new Question(q, a, "Use of pointers"));
	
	//2
	q = "The \\u0021 article referred to as a _____";
	// must reuse variable with new String[]
	// array constants can only be used during initialization
	a = new String[]{"Unicode escape sequence", "Octal escape", "Hexadecimal","Line feed"};
	questionSet.add(new Question(q, a, "Unicode escape sequence"));
	
	//3
	q = " _____ is used to find and fix bugs in the Java programs.";
	a = new String[]{"JVM", "JRE", "JDK", "JDB"};
	questionSet.add(new Question(q, a, "JDB"));
	
	//4
	q = " Which package contains the Random class?";
	a = new String[]{"java.util package", "java.lang package", "java.awt package", "java.io package"};
	questionSet.add(new Question(q, a, "java.util package"));
	
	//5
	q = "Which keyword is used for accessing the features of a package?";
	a = new String[]{"package", "import", "extends", "export"};
	questionSet.add(new Question(q, a, "import"));
	
	//6
	q = "In java, jar stands for_____.";
	a = new String[]{"Java Archive Runner", "Java Application Resource", "Java Application Runner", "None of the above"};
	questionSet.add(new Question(q, a, "None of the above"));
	
	//7
	q = "Which keyword is used for accessing the features of a package?";
	a = new String[]{"package", "import", "extends", "export"};
	questionSet.add(new Question(q, a, "import"));
	
	//8
	q = "Which of the following is not OOPS concept in Java?";
	a = new String[]{"Inheritance", "Encapsulation", "Polymorphism", "Compilation"};
	questionSet.add(new Question(q, a, "Compilation"));
	 
	Collections.shuffle(questionSet, new Random());
 }
 public void start() {
  Scanner scan = new Scanner(System.in);
  int numCorrect = 0;
  // show questions from questionSet
  for (int question = 0; question < questionSet.size(); question++) {
   System.out.println(questionSet.get(question).getQuestion());
   int numChoices = questionSet.get(question).getChoices().size();
   // show choices from questions in questionSet
   for (int choice = 0; choice < numChoices; choice++) {
    System.out.println((choice + 1) + ": " + 
      questionSet.get(question).getChoices().get(choice));
   }
   int playerAnswer = scan.nextInt();
   ArrayList<String> choiceSet = 
     questionSet.get(question).getChoices();
   String correctAnswer = questionSet.get(question).getAnswer();
   int correctAnswerIndex = choiceSet.indexOf(correctAnswer);
   if (playerAnswer == correctAnswerIndex + 1) {
    numCorrect++;
   }
  }
  scan.close();
  System.out.println("You got " + numCorrect + " correct answer(s)");
 }
}


















